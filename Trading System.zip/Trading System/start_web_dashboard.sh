#!/bin/bash

echo "============================================================"
echo "  Unified Trading System - Web Dashboard"
echo "============================================================"
echo ""
echo "Starting Flask server..."
echo "Open http://localhost:5000 in your browser"
echo ""
echo "Press Ctrl+C to stop the server"
echo "============================================================"
echo ""

python3 app.py
